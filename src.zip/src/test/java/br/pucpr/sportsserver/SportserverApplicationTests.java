package br.pucpr.sportsserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
